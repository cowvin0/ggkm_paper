#!/usr/bin/env bash
set -euo pipefail

mostrar_ajuda() {
  cat <<'EOF'
Uso: reproduzir.sh [--quick] [--workers N]

Reproduz os resultados, figuras, tabelas e PDFs do artigo GG-KM.

Opções:
  --quick       Executa os testes e duas replicações diagnósticas sem alterar escrita/.
  --workers N   Define o número de processos das análises numéricas.
  -h, --help    Exibe esta ajuda.
EOF
}

erro() {
  printf '%s\n' "erro: $*" >&2
  exit 1
}

QUICK=0
WORKERS=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --quick) QUICK=1 ;;
    --workers)
      [ "$#" -ge 2 ] || erro "--workers exige um número"
      shift
      WORKERS="$1"
      ;;
    --workers=*) WORKERS="${1#*=}" ;;
    --skip-compile) erro "--skip-compile não produz o pacote de escrita" ;;
    -h|--help) mostrar_ajuda; exit 0 ;;
    *) erro "opção desconhecida: $1" ;;
  esac
  shift
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACOTE="$(cd "$SCRIPT_DIR/.." && pwd)"
ARQUIVO="$SCRIPT_DIR/recursos-ggkm.zip"
ESCRITA="$PACOTE/escrita"
ESPERADO="47bbf321abd937deceba500a0d0abb4df4643d1b05e4464c76812cab0bcd169c"

[ -f "$ARQUIVO" ] || erro "recursos-ggkm.zip não foi encontrado"

# A validação do arquivo ocorre antes de qualquer extração ou instalação.
if command -v sha256sum >/dev/null 2>&1; then
  RESUMO="$(sha256sum "$ARQUIVO")"
elif command -v shasum >/dev/null 2>&1; then
  RESUMO="$(shasum -a 256 "$ARQUIVO")"
else
  erro "sha256sum ou shasum é necessário para validar recursos-ggkm.zip"
fi
RESUMO="${RESUMO%% *}"
[ "$RESUMO" = "$ESPERADO" ] || erro "recursos-ggkm.zip não corresponde a este pacote"

command -v python3 >/dev/null 2>&1 || erro "python3 não foi encontrado"
python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 12) else 1)' \
  || erro "python3 3.12 ou mais recente é necessário"
command -v unzip >/dev/null 2>&1 || erro "unzip não foi encontrado"
if [ "$QUICK" -eq 0 ]; then
  command -v latexmk >/dev/null 2>&1 || erro "latexmk não foi encontrado"
  command -v xelatex >/dev/null 2>&1 || erro "xelatex não foi encontrado"
fi
[ -d "$ESCRITA" ] || erro "o diretório irmão escrita não foi encontrado"

AREA_TEMP=""
NOVA_ESCRITA=""
ANTIGA_ESCRITA=""
limpar() {
  status=$?
  trap - EXIT
  if [ -n "$ANTIGA_ESCRITA" ] && [ -d "$ANTIGA_ESCRITA" ]; then
    if [ ! -d "$ESCRITA" ]; then
      mv "$ANTIGA_ESCRITA" "$ESCRITA" || true
    else
      rm -rf "$ANTIGA_ESCRITA"
    fi
  fi
  [ -z "$AREA_TEMP" ] || rm -rf "$AREA_TEMP"
  [ -z "$NOVA_ESCRITA" ] || rm -rf "$NOVA_ESCRITA"
  exit "$status"
}
trap limpar EXIT
trap 'exit 130' HUP INT TERM

# A área temporária impede que uma execução parcial altere o pacote atual.
AREA_TEMP="$(mktemp -d "${TMPDIR:-/tmp}/ggkm-reproducao.XXXXXX")"
unzip -q "$ARQUIVO" -d "$AREA_TEMP"
WORK="$AREA_TEMP/ggkm-reproducibility"
[ -f "$WORK/reproduce.sh" ] || erro "recursos-ggkm.zip não contém reproduce.sh"
mkdir -p "$WORK/article"
cp -R "$ESCRITA/." "$WORK/article/"

# O script principal limita bibliotecas numéricas a uma thread por processo.
ARGUMENTOS=()
[ "$QUICK" -eq 0 ] || ARGUMENTOS+=(--quick)
[ -z "$WORKERS" ] || ARGUMENTOS+=(--workers "$WORKERS")
bash "$WORK/reproduce.sh" "${ARGUMENTOS[@]}"

if [ "$QUICK" -eq 1 ]; then
  printf '%s\n' "reprodução rápida concluída sem alterar escrita/"
  exit 0
fi

GERADA="$WORK/submission/escrita"
for pdf in main.pdf main-submission.pdf supporting-information.pdf; do
  [ -f "$GERADA/$pdf" ] || erro "a reprodução integral não gerou $pdf"
done

# A troca tardia preserva escrita até que os três PDFs estejam disponíveis.
NOVA_ESCRITA="$(mktemp -d "$PACOTE/.escrita-nova.XXXXXX")"
cp -R "$GERADA/." "$NOVA_ESCRITA/"
ANTIGA_ESCRITA="$(mktemp -d "$PACOTE/.escrita-anterior.XXXXXX")"
rmdir "$ANTIGA_ESCRITA"
if ! mv "$ESCRITA" "$ANTIGA_ESCRITA"; then
  ANTIGA_ESCRITA=""
  erro "não foi possível preparar a troca de escrita/"
fi
if ! mv "$NOVA_ESCRITA" "$ESCRITA"; then
  if mv "$ANTIGA_ESCRITA" "$ESCRITA"; then
    ANTIGA_ESCRITA=""
  else
    erro "a troca falhou e escrita/ permaneceu em $ANTIGA_ESCRITA"
  fi
  erro "a troca falhou e a versão anterior de escrita/ foi restaurada"
fi
NOVA_ESCRITA=""
rm -rf "$ANTIGA_ESCRITA"
ANTIGA_ESCRITA=""
printf '%s\n' "reprodução integral concluída e escrita/ atualizada"
